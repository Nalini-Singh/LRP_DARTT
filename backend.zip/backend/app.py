from flask import Flask, request, jsonify
from modules import vulscanner, searchexploits, msfexploit, mitm_headless
import csv

app = Flask(__name__)

@app.route('/discover', methods=['POST'])
def discover():
    data = request.json
    network = data.get('network')
    vulscanner.discover(network)
    with open('outputs/hosts') as f:
        hosts = [h.strip() for h in f]
    return jsonify(hosts=hosts)

@app.route('/scan', methods=['POST'])
def scan():
    host = request.json
    prefix = vulscanner.vulscan(host)
    rows = []
    with open(f'{prefix}.csv') as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)
    return jsonify(scan=rows)

@app.route('/search_exploits', methods=['POST'])
def search_exploits():
    data = request.json
    host = data['host']
    service_row = data['service']
    searchexploits.global_positive_out.clear()
    searchexploits.search(host, service_row)
    return jsonify(exploits=searchexploits.global_positive_out)

@app.route('/exploit', methods=['POST'])
def exploit():
    data = request.json
    host = data['host']
    exploit_choice = data['exploit']
    msfexploit.exploit(host, exploit_choice)
    return jsonify(status='launched')

@app.route('/mitm', methods=['POST'])
def mitm():
    data = request.json
    info = [data['interface'], data['victim_ip'], data['gateway']]
    mitm_headless.start_mitm(info)
    return jsonify(status='mitm_started')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
