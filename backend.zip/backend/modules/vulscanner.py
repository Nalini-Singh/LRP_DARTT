import nmap
import pandas as pd
import csv
import xml.etree.cElementTree as et
import sys
import time
import os
def vulscan(Host):
    nm = nmap.PortScanner()
    host = Host['IP'].split('/')[0]
    fileName = "outputs/nmap-" + host + ".xml"
    fileHTML = "outputs/nmap-" + host + ".html"
    fileXML = open(fileName, "wb")
    # Create XML nmap report
    print("Inside Vulscan",fileName)

    # nm.scan(tgt, arguments='-sV -oN exists --script=/usr/share/nmap/scripts/vulscan/vulscan.nse')
    #print(Host['IP'])
    nm.scan(Host['IP'], arguments="-O -oN outputs/OS.txt")
    if Host['Port']!='':
        nm.scan(Host['IP'], arguments='-sV -sS -p '+Host['Port']+' --script=/usr/share/nmap/scripts/nmap-vulners/vulners.nse')
    else:
        nm.scan(Host['IP'], arguments='-sV -sS --script=/usr/share/nmap/scripts/nmap-vulners/vulners.nse')
    fileXML.write(nm.get_nmap_last_output())
    fileXML.close()
    os.system("xsltproc "+fileName+" -o "+fileHTML)
    file1 = parse2csv("outputs/nmap-" + host)
    time.sleep(3)
    os.system("xsltproc "+fileName+" -o "+fileHTML)
    #print("Saved file!")
    return file1

    #tkinter.messagebox.showinfo("Done", "Scanned the network")

def discover(Network):
    nm = nmap.PortScanner()
    nm.scan(Network,arguments=" -sn  -oN nmap_result")
    os.system("cat nmap_result | awk \'/Nmap scan/{gsub(/[()]/,\"\",$NF); print $NF > \"outputs/hosts\"}\'")
    os.system("rm nmap_result")


def parse2csv(xmlFile):
    Host = []
    Protocol = []
    Port = []
    State = []
    Service = []
    Product = []
    Version = []

    tree = et.parse(r''+xmlFile+'.xml')
    root = tree.getroot()

    for x in root.iter('nmaprun'):
        root1 = et.Element('root')
        root1 = x
        for host in root1.iter('host'):
            root2 = et.Element('root')
            #print(host)
            root2 = (host)
            for ports in root2.iter('ports'):
                root3 = et.Element('root')
                #print(ports)
                root3 = (ports)
                for port in root3.iter('port'):
                    root4 = et.Element('root')
                    #print(port)
                    root4 = (port)
                    if host.find('address').attrib['addrtype'] == 'ipv4':
                        Host.append(host.find('address').attrib['addr'])
                        #print(host.find('address').attrib['addr'])

                    Port.append(port.attrib['portid'])
                    Protocol.append(port.attrib['protocol'])
                    State.append(port.find('state').attrib['state'])
                    Service.append(port.find('service').attrib['name'])
                    try:
                        Product.append(port.find('service').attrib['product'] + '')
                    except KeyError:
                        Product.append('')
                    try:
                        Version.append(port.find('service').attrib['version'] + '')
                    except KeyError:
                        Version.append('')

    #print('Creating dataframe')

    test_df = pd.DataFrame(
        {'Host': Host,
         'Protocol': Protocol,
         'Port': Port,
         'State': State,
         'Service': Service,
         'Product': Product,
         'Version': Version})
    #print(test_df.head())

    test_df.to_csv(xmlFile + '.csv')
    return xmlFile
    #show_scan(xmlFile)
